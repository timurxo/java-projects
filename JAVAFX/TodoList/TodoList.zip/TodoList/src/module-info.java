module TodoList {

    requires javafx.fxml;
    requires javafx.controls;

    requires graphics;

    opens sample;

}